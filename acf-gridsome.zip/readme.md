=== Plugin Name ===
Contributors: ftpyz
Donate link: http://gurmewoo.com/
Tags: gridsome,acf,acf rest api
Requires at least: 5.1
Tested up to: 7.2
Requires PHP: 7.2
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
 
Use gridsome for source wordpress with acf field rest api
 
== Description ==
 

Using with gridsome source worpdress 
https://gridsome.org/plugins/@gridsome/source-wordpress

Use for custom acf fields get to rest api neccessery plugin for wordpress